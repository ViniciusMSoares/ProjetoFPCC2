
read_projectconsumo <- function(){
    readr::read_csv(here::here("data/consumos.csv"), 
                    col_types = cols(
                        .default = col_character(),
                        nome = col_character(),
                        data = col_character(),
                        hora = col_character(),
                        potencia = col_integer()
                    )) %>% 
        janitor::clean_names()
}

read_projecttemperatura <- function(){
    readr::read_csv(here::here("data/temperaturas.csv"), 
                    col_types = cols(
                        .default = col_character(),
                        data = col_character(),
                        hora = col_character(),
                        temperatura = col_double()
                    )) %>% 
        janitor::clean_names()
}
